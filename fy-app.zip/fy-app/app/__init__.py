"""FY-App — sistema modular de instalaciones eléctricas."""
__version__ = "0.20.1"
